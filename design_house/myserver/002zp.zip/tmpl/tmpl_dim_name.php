<?php
	{	$dim_name = '';		//	dimension_variable_name
		$dim_size = '15px';
		$arrow_xm = $xm;
		$arrow_ym = $ym;
		$arrow_ln = ;
		$extl = 0;
		$extr = 0;
		$arrow_level = -1;
		$arrow_rotate = 0;
		include 'dimension/dimension_arrow.php';
	}
?>
