
const counter1 = {
	properties : {length:3.5ft}
	draw0 : [],
	draw1 : [],
	draw2 : [],
	draw3 : [],
	draw4 : [],
	cupboard : [],
};

const counter2 = {
	properties = {length:3.5ft},
	draw0 : ['scales', '',],
	draw1 : [],
	draw2 : [],
	draw3 : [],
	draw4 : [],
	cupboard : [],
};