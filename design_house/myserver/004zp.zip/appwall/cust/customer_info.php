<!DOCTYPE html>
<html lang="en">
<head><?php
	$sr=$_GET['sr']; echo "<title>$sr Info</title>";
	$fdir='../../';  include $fdir.'svr/filepath.php';  include $bootstrapcdn_php;
	$svr_mode=$_GET['svr_mode'];  include $svr_mode_php;
	?><!--<style>body { overflow: hidden; }</style>-->
</head>
<body>

<?php
	error_reporting(E_ALL & ~E_NOTICE);
	$navtitle='Customer Info';  $navlink=$customer_info_php."?svr_mode=$svr_mode&sr=$sr&cs=0&csv=0";  include $navbar_php;
	if ($_GET['csv']==1)	include $sub_cust_save_php;
	if ($_GET['cs' ]==1) include $create_style_php;
?>

<h1 class="pb-3">Customer Info</h1>
<div class="container-fluid pl-5 pr-5">
	
	<div class="container-fluid px-5 pt-4 pb-3">
		<div class="row no-gutters" id='head_row'></div>
	</div><hr/>
	
	<form method="post" action=<?php echo $pattern_php."?svr_mode=$svr_mode&sr=$sr&csv=0&msv=0";?> >
		<div class="form-group">
			<div class="d-flex flex-wrap align-content-around" id='style_row'></div>
		</div><hr/>
	</form>
	
	<form method="post" action=<?php echo $customer_info_php."?svr_mode=$svr_mode&sr=$sr&cs=1&csv=0";?> >
	<div class="form-group"><div class="d-flex flex-wrap align-content-around">
		<div class="p-4"><label for="garbtype">Type</label>
		<select class="form-control p-1" name="garbtype" id="garbtype" onchange="ChangeGarbStyle()" style="width:100px">
			<option value="shirt"  >shirt  </option>
			<option value="kurta"  >kurta  </option>
			<option value="kandura">kandura</option>
			<option value="pant"   >pant   </option>
			<option value="salwar" >salwar </option>
		</select></div>
		<div class="p-4"><label for="garbstyle">Style</label>
		<select class="form-control p-1" name="garbstyle" id="garbstyle" style="width:100px">
				<option value=""></option>
			<optgroup label="pant">
				<option value="bpyjama">bpyjama</option>
				<option value="pyjama">pyjama</option>
			</optgroup>
			<optgroup label="salwar">
				<option value="aligard">aligard</option>
			</optgroup>
		</select></div>
		<div class="p-4"><label for="garbsubstyle">Sub Style</label>
		<input type="text" class="form-control p-2" name="garbsubstyle" value="" style="width:100px" /></div>
		<button type="submit" class="btn btn-info mx-4 my-5 p-2" name="submit" value="save" style="height:42px">Create Style</button>
	</div></div><hr/>
	</form>
	
</div>

<script>
	let url		= new URL(window.location.href);
	let svr_mode= url.searchParams.get("svr_mode");
	let sr		= url.searchParams.get("sr");
</script>
<script src="<?php echo $fme_select_option_change_js	?>" ></script>
<script src="<?php echo $loaddoc_js							?>"></script>
<script src="<?php echo $head_row_js						?>"></script>
<script src="<?php echo $style_row_js						?>"></script>
<?php mysqli_close($dbc); ?>

</body>
</html>