<?php
	
	function scale($x) {
		$a = $x * 1500 / inchtocm(31.5) ;
		return $a;
	}
	
?>