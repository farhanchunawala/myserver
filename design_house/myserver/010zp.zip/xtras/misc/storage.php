<?php
$counter1 {
	$draw1
	$draw2
	$draw3
	$draw4
	$cupboard
}

$counter2 {
	$draw1
	$draw2
	$draw3
	$draw4
	$cupboard
}
?>