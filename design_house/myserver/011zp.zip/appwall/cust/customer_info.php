<!DOCTYPE html>
<html lang="en">
<head>
	<?php $sr=$_GET['sr'];  echo "<title>$sr Entry</title>";
	$fdir='../../';  include $fdir.'svr/filepath.php';  include $bootstrapcdn_php;
	$svr_mode=$_GET['svr_mode'];  include $svr_mode_php; ?>
	<script src="https://unpkg.com/vue"></script>
	<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
	<link rel="stylesheet" href="<?php echo $searchfilter_css ?>">
	<style>
		th {padding: 5px;
			background-color: white;
			position: -webkit-sticky;
			position: sticky;
			top: 0;
			white-space: nowrap;
		}
		td {white-space: nowrap;
		}
	</style>
</head>
<body>
<?php
	include $fn_inchtotextround2_php;
	include $fn_cmtoinchtext_php;
	
	if ($_GET['cs']==1) include $create_style_php;
?>

<div id="app" class="container-fluid mx-n2">
<form method="post" action="<?php echo "$pattern_save2_php?svr_mode=$svr_mode&sr=$sr"; ?>" >
	<div id="accordion">
		
		<div class="card" style="width:460px">
			<div class="card-header"><a class="btn" data-bs-toggle="collapse" href="#collapse1" style="color:black"><b>{{cust.sr+' '+cust.name+' '+cust.surname}}</b></a></div>
			<div id="collapse1" class="collapse" data-bs-parent="#accordion"><div class="card-body p-2">
				<span v-for="(x,kx) in cust" :key="kx"><label :for="kx" class="p-2">{{kx}}
					<input tabindex="1" type="text" class="form-control p-1" :name="kx" :value="x" style="width:130px" />
				</label></span>
			</div></div>
		</div>
		
		<div class="card" style="width:460px">
			<div class="card-header"><a class="btn" data-bs-toggle="collapse" href="#collapse2" style="color:black"><b>Body Measure</b></a></div>
			<div id="collapse2" class="collapse" data-bs-parent="#accordion"><div class="card-body p-0">
				<!-- <div class="form-group form-inline d-flex flex-wrap align-content-around">
				<div v-for="(x,kx) in meas" :key="kx" style="padding:5px 5px">
					<label class="form-inline" :for="kx">{{kx}}</label>
					<div><div class="btn-group">
					<input  tabindex="110" type="text"  class="myInput"  id=""  value=""					style="width:60px"  oninput=inchtocm(this.value,"")  onchange=inchtocm(this.value,"") />
					<input  tabindex="130" type="text"  class="myInput"  id=""  value=""  :name="kx"	style="width:50px"  oninput=cmtoinch(this.value,"")  onchange=cmtoinch(this.value,"") />
				</div></div></div></div> -->
				<table class="table table-borderless table-sm">
				<thead><tr><th></th></tr></thead>
				<tbody>
					<template v-for="(x,kx) in meas" :key="kx"><template v-if="kx!='sr' && kx!='measure_date' && kx!='lat' && kx!='half_delt' && kx!='delt_ln'">
					<template v-if="kx=='biceps_ln' || kx=='pec' || kx=='forearm_ln' || kx=='arm_ln' || kx=='chest_ln' || kx=='stomach_ln' || kx=='seat_ln' || kx=='knee_ln' || kx=='thigh_ln' || kx=='lower_thigh_ln' || kx=='calf_ln' || kx=='ground_ln'"><tr></template>
						<td style="padding:5px 2px 5px 10px">{{kx}}</td>
						<td style="padding:1px 10px 1px 2px"><div class="btn-group p-0">
							<input  tabindex="120" type="text"  class="myInput"  :id="kx+'x'+'in'"  value=""					style="width:60px; background-color:hsl(230, 0%, 98%)" />
							<input  tabindex="141" type="text"  class="myInput"  :id="kx+'x'+'cm'"  value=""  :name="kx+'x'"	style="width:50px" />
						</div></td>
					<template v-if="kx=='biceps_ln' || kx=='pec' || kx=='forearm_ln' || kx=='arm_ln'|| kx=='chest_ln' || kx=='stomach_ln' || kx=='seat_ln' || kx=='knee_ln' || kx=='thigh_ln' || kx=='lower_thigh_ln' || kx=='calf_ln' || kx=='ground_ln'"></tr></template>
					</template></template>
				<tbody>
				</table>
			</div></div>
		</div>
		
	</div>
	
	<div class="form-group form-inline"><div class="d-flex flex-nowrap bg-light">
	<div v-for="(garb,type_key) in garbstyles">
	<div :id="'accordion'+type_key" v-if="garb['0']">
	<div class="card">
		<div class="card-header" style="white-space:nowrap">
			<a class="btn" data-bs-toggle="collapse" :href="'#collapse'+type_key" style="color:black"><b>{{type_key+' x '+garb.length}}</b></a>
			<button type="button" @click="removeType(garb, type_key)" class="btn btn-outline-secondary btn-sm" style="width:30px" >-</button>
			<button type="button" @click="addType(garb, type_key)" class="btn btn-outline-secondary btn-sm ms-1" style="width:30px" >+</button>
		</div>
		<div :id="'collapse'+type_key" class="collapse show" :data-bs-parent="'#accordion'+type_key"><div class="card-body px-2 py-0">
			<!--<div class="form-group form-inline"><div class="d-flex flex-nowrap bg-light">-->
				<styletable :garb="garb" :garbtype="type_key" :garbstyles="garb" ></styletable>
			<!-- </div></div> -->
		</div></div>
	</div>
	</div>
	</div>
	</div></div>
	
	<input class="myInput" type="text" @click="lmkChange()">
	<ul id="myUL" v-show="lmk"><li>
		<a v-for="(garb,type_key) in garbs" @click="addType(garb, type_key)" >{{type_key}}</a>
	</li></ul>
	
</form>{{garbstyles}}
</div>

<script> "use strict";
	var fdir = '../../';
	let url		= new URL(window.location.href);
	let svr_mode= url.searchParams.get("svr_mode");
	let sr		= url.searchParams.get("sr");
</script>
<script>
const app = Vue.createApp({
	data() {
		return {
			cust:		{},
			meas:		{},
			styles:	[],
			fits:		[],
         garbstyles: {shirt:[], kurta:[], thobe:[], pant:[], salwar:[]},
			garbs: {shirt:{}, kurta:[], thobe:{}, pant:{}, salwar:{}},
			lmk: 0
		}
	},
	methods: {
		lmkChange()			{ this.lmk=1 },
		addType(garb,type_key)		{ this.garbstyles[type_key].push('0'); (garb.count) ? garb.count+=1 : garb.count=1 ; this.lmk=0;  },
		removeType(garb,type_key)	{ this.garbstyles[type_key].pop(); garb.count-=1 }
	},
	created() {
		axios.post(fdir+'qry/pdo_select.php?svr_mode='+svr_mode, {
		sql: 'SELECT * FROM style WHERE sr='+sr
		}).then(response => { this.styles = response.data
		}).catch(error => { console.log(error); this.errored1 = true
		}).finally(() => this.loading1 = false)
		
		axios.post(fdir+'qry/pdo_select.php?svr_mode='+svr_mode, {
		sql: 'SELECT * FROM fit WHERE sr='+sr
		}).then(response => { this.fits = response.data
		}).catch(error => { console.log(error); this.errored1 = true
		}).finally(() => this.loading1 = false)
		
		axios.post(fdir+'qry/pdo_select.php?svr_mode='+svr_mode, {
		sql: 'SELECT * FROM meas WHERE sr='+sr
		}).then(response => { this.meas = response.data[0]
		}).catch(error => { console.log(error); this.errored1 = true
		}).finally(() => this.loading1 = false)
		
		axios.post(fdir+'qry/pdo_select.php?svr_mode='+svr_mode, {
		sql: 'SELECT * FROM cust WHERE sr='+sr
		}).then(response => { this.cust = response.data[0]
		}).catch(error => { console.log(error); this.errored1 = true
		}).finally(() => this.loading1 = false)
	}
})
</script>
<script src="<?php echo $styletable_js; ?>"></script>
<script> const mountedApp = app.mount('#app') </script>
<?php mysqli_close($dbc); ?>
</body>
</html>