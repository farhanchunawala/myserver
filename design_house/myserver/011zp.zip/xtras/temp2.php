<html>
				<div class="row p-3 no-gutters">
					<div class="col"></div>
					<div class="col"></div>
					<div class="col"></div>
					<div class="col"></div>
					<div class="col"></div>
					<div class="col"></div>
				</div>
				
<style>
.shirt_front {
	display: grid;
	grid-template-columns: auto auto auto auto auto auto auto auto auto auto auto auto auto auto auto auto auto auto auto auto 
						   auto auto auto auto auto auto auto auto auto auto;
	padding: 10px;
}

.a1 {
	grid-column: 1 / 5;
</style>
				
<div class="shirt_front">
	<div class="1_1"></div>
	<div class="1_2"></div>
	<div class="1_3"></div>
	<div class="1_4"></div>
	<div class="1_5"></div>
	<div class="1_6"></div>
	<div class="1_7"></div>
	<div class="1_8"></div>
	<div class="1_9"></div>
	<div class="1_10"></div>
	<div class="1_11"></div>
	<div class="1_12"></div>
	<div class="1_13"></div>
	<div class="1_14"></div>
	<div class="1_15"></div>
	<div class="1_16"></div>
	<div class="1_17"></div>
	<div class="1_18"></div>
	<div class="1_19"></div>
	<div class="1_20"></div>
	<div class="1_21"></div>
	<div class="1_22"></div>
	<div class="1_23"></div>
	<div class="1_24"></div>
	<div class="1_25"></div>
	<div class="1_26"></div>
	<div class="1_27"></div>
	<div class="1_28"></div>
	<div class="1_29"></div>
	<div class="1_30"></div>
	
	<div class="2_1"></div>
	<div class="2_2"></div>
	<div class="2_3"></div>
	<div class="2_4"></div>
	<div class="2_5"></div>
	<div class="2_6"></div>
	<div class="2_7"></div>
	<div class="2_8"></div>
	<div class="2_9"></div>
	<div class="2_10"></div>
	<div class="2_11"></div>
	<div class="2_12"></div>
	<div class="2_13"></div>
	<div class="2_14"></div>
	<div class="2_15"></div>
	<div class="2_16"></div>
	<div class="2_17"></div>
	<div class="2_18"></div>
	<div class="2_19"></div>
	<div class="2_20"></div>
	<div class="2_21"></div>
	<div class="2_22"></div>
	<div class="2_23"></div>
	<div class="2_24"></div>
	<div class="2_25"></div>
	<div class="2_26"></div>
	<div class="2_27"></div>
	<div class="2_28"></div>
	<div class="2_29"></div>
	<div class="2_30"></div>
	
	<div class="3_1"></div>
	<div class="3_2"></div>
	<div class="3_3"></div>
	<div class="3_4"></div>
	<div class="3_5"></div>
	<div class="3_6"></div>
	<div class="3_7"></div>
	<div class="3_8"></div>
	<div class="3_9"></div>
	<div class="3_10"></div>
	<div class="3_11"></div>
	<div class="3_12"></div>
	<div class="3_13"></div>
	<div class="3_14"></div>
	<div class="3_15"></div>
	<div class="3_16"></div>
	<div class="3_17"></div>
	<div class="3_18"></div>
	<div class="3_19"></div>
	<div class="3_20"></div>
	<div class="3_21"></div>
	<div class="3_22"></div>
	<div class="3_23"></div>
	<div class="3_24"></div>
	<div class="3_25"></div>
	<div class="3_26"></div>
	<div class="3_27"></div>
	<div class="3_28"></div>
	<div class="3_29"></div>
	<div class="3_30"></div>
	
	<div class="4_1"></div>
	<div class="4_2"></div>
	<div class="4_3"></div>
	<div class="4_4"></div>
	<div class="4_5"></div>
	<div class="4_6"></div>
	<div class="4_7"></div>
	<div class="4_8"></div>
	<div class="4_9"></div>
	<div class="4_10"></div>
	<div class="4_11"></div>
	<div class="4_12"></div>
	<div class="4_13"></div>
	<div class="4_14"></div>
	<div class="4_15"></div>
	<div class="4_16"></div>
	<div class="4_17"></div>
	<div class="4_18"></div>
	<div class="4_19"></div>
	<div class="4_20"></div>
	<div class="4_21"></div>
	<div class="4_22"></div>
	<div class="4_23"></div>
	<div class="4_24"></div>
	<div class="4_25"></div>
	<div class="4_26"></div>
	<div class="4_27"></div>
	<div class="4_28"></div>
	<div class="4_29"></div>
	<div class="4_30"></div>
	
	<div class="5_1"></div>
	<div class="5_2"></div>
	<div class="5_3"></div>
	<div class="5_4"></div>
	<div class="5_5"></div>
	<div class="5_6"></div>
	<div class="5_7"></div>
	<div class="5_8"></div>
	<div class="5_9"></div>
	<div class="5_10"></div>
	<div class="5_11"></div>
	<div class="5_12"></div>
	<div class="5_13"></div>
	<div class="5_14"></div>
	<div class="5_15"></div>
	<div class="5_16"></div>
	<div class="5_17"></div>
	<div class="5_18"></div>
	<div class="5_19"></div>
	<div class="5_20"></div>
	<div class="5_21"></div>
	<div class="5_22"></div>
	<div class="5_23"></div>
	<div class="5_24"></div>
	<div class="5_25"></div>
	<div class="5_26"></div>
	<div class="5_27"></div>
	<div class="5_28"></div>
	<div class="5_29"></div>
	<div class="5_30"></div>
	
	<div class="6_1"></div>
	<div class="6_2"></div>
	<div class="6_3"></div>
	<div class="6_4"></div>
	<div class="6_5"></div>
	<div class="6_6"></div>
	<div class="6_7"></div>
	<div class="6_8"></div>
	<div class="6_9"></div>
	<div class="6_10"></div>
	<div class="6_11"></div>
	<div class="6_12"></div>
	<div class="6_13"></div>
	<div class="6_14"></div>
	<div class="6_15"></div>
	<div class="6_16"></div>
	<div class="6_17"></div>
	<div class="6_18"></div>
	<div class="6_19"></div>
	<div class="6_20"></div>
	<div class="6_21"></div>
	<div class="6_22"></div>
	<div class="6_23"></div>
	<div class="6_24"></div>
	<div class="6_25"></div>
	<div class="6_26"></div>
	<div class="6_27"></div>
	<div class="6_28"></div>
	<div class="6_29"></div>
	<div class="6_30"></div>
	
	<div class="7_1"></div>
	<div class="7_2"></div>
	<div class="7_3"></div>
	<div class="7_4"></div>
	<div class="7_5"></div>
	<div class="7_6"></div>
	<div class="7_7"></div>
	<div class="7_8"></div>
	<div class="7_9"></div>
	<div class="7_10"></div>
	<div class="7_11"></div>
	<div class="7_12"></div>
	<div class="7_13"></div>
	<div class="7_14"></div>
	<div class="7_15"></div>
	<div class="7_16"></div>
	<div class="7_17"></div>
	<div class="7_18"></div>
	<div class="7_19"></div>
	<div class="7_20"></div>
	<div class="7_21"></div>
	<div class="7_22"></div>
	<div class="7_23"></div>
	<div class="7_24"></div>
	<div class="7_25"></div>
	<div class="7_26"></div>
	<div class="7_27"></div>
	<div class="7_28"></div>
	<div class="7_29"></div>
	<div class="7_30"></div>
	
	<div class="8_1"></div>
	<div class="8_2"></div>
	<div class="8_3"></div>
	<div class="8_4"></div>
	<div class="8_5"></div>
	<div class="8_6"></div>
	<div class="8_7"></div>
	<div class="8_8"></div>
	<div class="8_9"></div>
	<div class="8_10"></div>
	<div class="8_11"></div>
	<div class="8_12"></div>
	<div class="8_13"></div>
	<div class="8_14"></div>
	<div class="8_15"></div>
	<div class="8_16"></div>
	<div class="8_17"></div>
	<div class="8_18"></div>
	<div class="8_19"></div>
	<div class="8_20"></div>
	<div class="8_21"></div>
	<div class="8_22"></div>
	<div class="8_23"></div>
	<div class="8_24"></div>
	<div class="8_25"></div>
	<div class="8_26"></div>
	<div class="8_27"></div>
	<div class="8_28"></div>
	<div class="8_29"></div>
	<div class="8_30"></div>
	
	<div class="9_1"></div>
	<div class="9_2"></div>
	<div class="9_3"></div>
	<div class="9_4"></div>
	<div class="9_5"></div>
	<div class="9_6"></div>
	<div class="9_7"></div>
	<div class="9_8"></div>
	<div class="9_9"></div>
	<div class="9_10"></div>
	<div class="9_11"></div>
	<div class="9_12"></div>
	<div class="9_13"></div>
	<div class="9_14"></div>
	<div class="9_15"></div>
	<div class="9_16"></div>
	<div class="9_17"></div>
	<div class="9_18"></div>
	<div class="9_19"></div>
	<div class="9_20"></div>
	<div class="9_21"></div>
	<div class="9_22"></div>
	<div class="9_23"></div>
	<div class="9_24"></div>
	<div class="9_25"></div>
	<div class="9_26"></div>
	<div class="9_27"></div>
	<div class="9_28"></div>
	<div class="9_29"></div>
	<div class="9_30"></div>
	
	<div class="10_1"></div>
	<div class="10_2"></div>
	<div class="10_3"></div>
	<div class="10_4"></div>
	<div class="10_5"></div>
	<div class="10_6"></div>
	<div class="10_7"></div>
	<div class="10_8"></div>
	<div class="10_9"></div>
	<div class="10_10"></div>
	<div class="10_11"></div>
	<div class="10_12"></div>
	<div class="10_13"></div>
	<div class="10_14"></div>
	<div class="10_15"></div>
	<div class="10_16"></div>
	<div class="10_17"></div>
	<div class="10_18"></div>
	<div class="10_19"></div>
	<div class="10_20"></div>
	<div class="10_21"></div>
	<div class="10_22"></div>
	<div class="10_23"></div>
	<div class="10_24"></div>
	<div class="10_25"></div>
	<div class="10_26"></div>
	<div class="10_27"></div>
	<div class="10_28"></div>
	<div class="10_29"></div>
	<div class="10_30"></div>
	
	<div class="11_1"></div>
	<div class="11_2"></div>
	<div class="11_3"></div>
	<div class="11_4"></div>
	<div class="11_5"></div>
	<div class="11_6"></div>
	<div class="11_7"></div>
	<div class="11_8"></div>
	<div class="11_9"></div>
	<div class="11_10"></div>
	<div class="11_11"></div>
	<div class="11_12"></div>
	<div class="11_13"></div>
	<div class="11_14"></div>
	<div class="11_15"></div>
	<div class="11_16"></div>
	<div class="11_17"></div>
	<div class="11_18"></div>
	<div class="11_19"></div>
	<div class="11_20"></div>
	<div class="11_21"></div>
	<div class="11_22"></div>
	<div class="11_23"></div>
	<div class="11_24"></div>
	<div class="11_25"></div>
	<div class="11_26"></div>
	<div class="11_27"></div>
	<div class="11_28"></div>
	<div class="11_29"></div>
	<div class="11_30"></div>
	
	<div class="12_1"></div>
	<div class="12_2"></div>
	<div class="12_3"></div>
	<div class="12_4"></div>
	<div class="12_5"></div>
	<div class="12_6"></div>
	<div class="12_7"></div>
	<div class="12_8"></div>
	<div class="12_9"></div>
	<div class="12_10"></div>
	<div class="12_11"></div>
	<div class="12_12"></div>
	<div class="12_13"></div>
	<div class="12_14"></div>
	<div class="12_15"></div>
	<div class="12_16"></div>
	<div class="12_17"></div>
	<div class="12_18"></div>
	<div class="12_19"></div>
	<div class="12_20"></div>
	<div class="12_21"></div>
	<div class="12_22"></div>
	<div class="12_23"></div>
	<div class="12_24"></div>
	<div class="12_25"></div>
	<div class="12_26"></div>
	<div class="12_27"></div>
	<div class="12_28"></div>
	<div class="12_29"></div>
	<div class="12_30"></div>
	
	<div class="13_1"></div>
	<div class="13_2"></div>
	<div class="13_3"></div>
	<div class="13_4"></div>
	<div class="13_5"></div>
	<div class="13_6"></div>
	<div class="13_7"></div>
	<div class="13_8"></div>
	<div class="13_9"></div>
	<div class="13_10"></div>
	<div class="13_11"></div>
	<div class="13_12"></div>
	<div class="13_13"></div>
	<div class="13_14"></div>
	<div class="13_15"></div>
	<div class="13_16"></div>
	<div class="13_17"></div>
	<div class="13_18"></div>
	<div class="13_19"></div>
	<div class="13_20"></div>
	<div class="13_21"></div>
	<div class="13_22"></div>
	<div class="13_23"></div>
	<div class="13_24"></div>
	<div class="13_25"></div>
	<div class="13_26"></div>
	<div class="13_27"></div>
	<div class="13_28"></div>
	<div class="13_29"></div>
	<div class="13_30"></div>
	
	<div class="14_1"></div>
	<div class="14_2"></div>
	<div class="14_3"></div>
	<div class="14_4"></div>
	<div class="14_5"></div>
	<div class="14_6"></div>
	<div class="14_7"></div>
	<div class="14_8"></div>
	<div class="14_9"></div>
	<div class="14_10"></div>
	<div class="14_11"></div>
	<div class="14_12"></div>
	<div class="14_13"></div>
	<div class="14_14"></div>
	<div class="14_15"></div>
	<div class="14_16"></div>
	<div class="14_17"></div>
	<div class="14_18"></div>
	<div class="14_19"></div>
	<div class="14_20"></div>
	<div class="14_21"></div>
	<div class="14_22"></div>
	<div class="14_23"></div>
	<div class="14_24"></div>
	<div class="14_25"></div>
	<div class="14_26"></div>
	<div class="14_27"></div>
	<div class="14_28"></div>
	<div class="14_29"></div>
	<div class="14_30"></div>
	
	<div class="15_1"></div>
	<div class="15_2"></div>
	<div class="15_3"></div>
	<div class="15_4"></div>
	<div class="15_5"></div>
	<div class="15_6"></div>
	<div class="15_7"></div>
	<div class="15_8"></div>
	<div class="15_9"></div>
	<div class="15_10"></div>
	<div class="15_11"></div>
	<div class="15_12"></div>
	<div class="15_13"></div>
	<div class="15_14"></div>
	<div class="15_15"></div>
	<div class="15_16"></div>
	<div class="15_17"></div>
	<div class="15_18"></div>
	<div class="15_19"></div>
	<div class="15_20"></div>
	<div class="15_21"></div>
	<div class="15_22"></div>
	<div class="15_23"></div>
	<div class="15_24"></div>
	<div class="15_25"></div>
	<div class="15_26"></div>
	<div class="15_27"></div>
	<div class="15_28"></div>
	<div class="15_29"></div>
	<div class="15_30"></div>
	
	<div class="16_1"></div>
	<div class="16_2"></div>
	<div class="16_3"></div>
	<div class="16_4"></div>
	<div class="16_5"></div>
	<div class="16_6"></div>
	<div class="16_7"></div>
	<div class="16_8"></div>
	<div class="16_9"></div>
	<div class="16_10"></div>
	<div class="16_11"></div>
	<div class="16_12"></div>
	<div class="16_13"></div>
	<div class="16_14"></div>
	<div class="16_15"></div>
	<div class="16_16"></div>
	<div class="16_17"></div>
	<div class="16_18"></div>
	<div class="16_19"></div>
	<div class="16_20"></div>
	<div class="16_21"></div>
	<div class="16_22"></div>
	<div class="16_23"></div>
	<div class="16_24"></div>
	<div class="16_25"></div>
	<div class="16_26"></div>
	<div class="16_27"></div>
	<div class="16_28"></div>
	<div class="16_29"></div>
	<div class="16_30"></div>
	
	<div class="17_1"></div>
	<div class="17_2"></div>
	<div class="17_3"></div>
	<div class="17_4"></div>
	<div class="17_5"></div>
	<div class="17_6"></div>
	<div class="17_7"></div>
	<div class="17_8"></div>
	<div class="17_9"></div>
	<div class="17_10"></div>
	<div class="17_11"></div>
	<div class="17_12"></div>
	<div class="17_13"></div>
	<div class="17_14"></div>
	<div class="17_15"></div>
	<div class="17_16"></div>
	<div class="17_17"></div>
	<div class="17_18"></div>
	<div class="17_19"></div>
	<div class="17_20"></div>
	<div class="17_21"></div>
	<div class="17_22"></div>
	<div class="17_23"></div>
	<div class="17_24"></div>
	<div class="17_25"></div>
	<div class="17_26"></div>
	<div class="17_27"></div>
	<div class="17_28"></div>
	<div class="17_29"></div>
	<div class="17_30"></div>
	
	<div class="18_1"></div>
	<div class="18_2"></div>
	<div class="18_3"></div>
	<div class="18_4"></div>
	<div class="18_5"></div>
	<div class="18_6"></div>
	<div class="18_7"></div>
	<div class="18_8"></div>
	<div class="18_9"></div>
	<div class="18_10"></div>
	<div class="18_11"></div>
	<div class="18_12"></div>
	<div class="18_13"></div>
	<div class="18_14"></div>
	<div class="18_15"></div>
	<div class="18_16"></div>
	<div class="18_17"></div>
	<div class="18_18"></div>
	<div class="18_19"></div>
	<div class="18_20"></div>
	<div class="18_21"></div>
	<div class="18_22"></div>
	<div class="18_23"></div>
	<div class="18_24"></div>
	<div class="18_25"></div>
	<div class="18_26"></div>
	<div class="18_27"></div>
	<div class="18_28"></div>
	<div class="18_29"></div>
	<div class="18_30"></div>
	
	<div class="19_1"></div>
	<div class="19_2"></div>
	<div class="19_3"></div>
	<div class="19_4"></div>
	<div class="19_5"></div>
	<div class="19_6"></div>
	<div class="19_7"></div>
	<div class="19_8"></div>
	<div class="19_9"></div>
	<div class="19_10"></div>
	<div class="19_11"></div>
	<div class="19_12"></div>
	<div class="19_13"></div>
	<div class="19_14"></div>
	<div class="19_15"></div>
	<div class="19_16"></div>
	<div class="19_17"></div>
	<div class="19_18"></div>
	<div class="19_19"></div>
	<div class="19_20"></div>
	<div class="19_21"></div>
	<div class="19_22"></div>
	<div class="19_23"></div>
	<div class="19_24"></div>
	<div class="19_25"></div>
	<div class="19_26"></div>
	<div class="19_27"></div>
	<div class="19_28"></div>
	<div class="19_29"></div>
	<div class="19_30"></div>
	
	<div class="20_1"></div>
	<div class="20_2"></div>
	<div class="20_3"></div>
	<div class="20_4"></div>
	<div class="20_5"></div>
	<div class="20_6"></div>
	<div class="20_7"></div>
	<div class="20_8"></div>
	<div class="20_9"></div>
	<div class="20_10"></div>
	<div class="20_11"></div>
	<div class="20_12"></div>
	<div class="20_13"></div>
	<div class="20_14"></div>
	<div class="20_15"></div>
	<div class="20_16"></div>
	<div class="20_17"></div>
	<div class="20_18"></div>
	<div class="20_19"></div>
	<div class="20_20"></div>
	<div class="20_21"></div>
	<div class="20_22"></div>
	<div class="20_23"></div>
	<div class="20_24"></div>
	<div class="20_25"></div>
	<div class="20_26"></div>
	<div class="20_27"></div>
	<div class="20_28"></div>
	<div class="20_29"></div>
	<div class="20_30"></div>
</div>

<div class="shirt_front">
	<div class="20_30"></div>
	<div class="20_29"></div>
	<div class="20_28"></div>
	<div class="20_27"></div>
	<div class="20_26"></div>
	<div class="20_25"></div>
	<div class="20_24"></div>
	<div class="20_23"></div>
	<div class="20_22"></div>
	<div class="20_21"></div>
	<div class="20_20"></div>
	<div class="20_19"></div>
	<div class="20_18"></div>
	<div class="20_17"></div>
	<div class="20_16"></div>
	<div class="20_15"></div>
	<div class="20_14"></div>
	<div class="20_13"></div>
	<div class="20_12"></div>
	<div class="20_11"></div>
	<div class="20_10"></div>
	<div class="20_9"></div>
	<div class="20_8"></div>
	<div class="20_7"></div>
	<div class="20_6"></div>
	<div class="20_5"></div>
	<div class="20_4"></div>
	<div class="20_3"></div>
	<div class="20_2"></div>
	<div class="20_1"></div>
	<div class="20_0"></div>
	
	<div class="19_30"></div>
	<div class="19_29"></div>
	<div class="19_28"></div>
	<div class="19_27"></div>
	<div class="19_26"></div>
	<div class="19_25"></div>
	<div class="19_24"></div>
	<div class="19_23"></div>
	<div class="19_22"></div>
	<div class="19_21"></div>
	<div class="19_20"></div>
	<div class="19_19"></div>
	<div class="19_18"></div>
	<div class="19_17"></div>
	<div class="19_16"></div>
	<div class="19_15"></div>
	<div class="19_14"></div>
	<div class="19_13"></div>
	<div class="19_12"></div>
	<div class="19_11"></div>
	<div class="19_10"></div>
	<div class="19_9"></div>
	<div class="19_8"></div>
	<div class="19_7"></div>
	<div class="19_6"></div>
	<div class="19_5"></div>
	<div class="19_4"></div>
	<div class="19_3"></div>
	<div class="19_2"></div>
	<div class="19_1"></div>
	<div class="19_0"></div>
	
	<div class="18_30"></div>
	<div class="18_29"></div>
	<div class="18_28"></div>
	<div class="18_27"></div>
	<div class="18_26"></div>
	<div class="18_25"></div>
	<div class="18_24"></div>
	<div class="18_23"></div>
	<div class="18_22"></div>
	<div class="18_21"></div>
	<div class="18_20"></div>
	<div class="18_19"></div>
	<div class="18_18"></div>
	<div class="18_17"></div>
	<div class="18_16"></div>
	<div class="18_15"></div>
	<div class="18_14"></div>
	<div class="18_13"></div>
	<div class="18_12"></div>
	<div class="18_11"></div>
	<div class="18_10"></div>
	<div class="18_9"></div>
	<div class="18_8"></div>
	<div class="18_7"></div>
	<div class="18_6"></div>
	<div class="18_5"></div>
	<div class="18_4"></div>
	<div class="18_3"></div>
	<div class="18_2"></div>
	<div class="18_1"></div>
	<div class="18_0"></div>
	
	<div class="17_30"></div>
	<div class="17_29"></div>
	<div class="17_28"></div>
	<div class="17_27"></div>
	<div class="17_26"></div>
	<div class="17_25"></div>
	<div class="17_24"></div>
	<div class="17_23"></div>
	<div class="17_22"></div>
	<div class="17_21"></div>
	<div class="17_20"></div>
	<div class="17_19"></div>
	<div class="17_18"></div>
	<div class="17_17"></div>
	<div class="17_16"></div>
	<div class="17_15"></div>
	<div class="17_14"></div>
	<div class="17_13"></div>
	<div class="17_12"></div>
	<div class="17_11"></div>
	<div class="17_10"></div>
	<div class="17_9"></div>
	<div class="17_8"></div>
	<div class="17_7"></div>
	<div class="17_6"></div>
	<div class="17_5"></div>
	<div class="17_4"></div>
	<div class="17_3"></div>
	<div class="17_2"></div>
	<div class="17_1"></div>
	<div class="17_0"></div>
	
	<div class="16_30"></div>
	<div class="16_29"></div>
	<div class="16_28"></div>
	<div class="16_27"></div>
	<div class="16_26"></div>
	<div class="16_25"></div>
	<div class="16_24"></div>
	<div class="16_23"></div>
	<div class="16_22"></div>
	<div class="16_21"></div>
	<div class="16_20"></div>
	<div class="16_19"></div>
	<div class="16_18"></div>
	<div class="16_17"></div>
	<div class="16_16"></div>
	<div class="16_15"></div>
	<div class="16_14"></div>
	<div class="16_13"></div>
	<div class="16_12"></div>
	<div class="16_11"></div>
	<div class="16_10"></div>
	<div class="16_9"></div>
	<div class="16_8"></div>
	<div class="16_7"></div>
	<div class="16_6"></div>
	<div class="16_5"></div>
	<div class="16_4"></div>
	<div class="16_3"></div>
	<div class="16_2"></div>
	<div class="16_1"></div>
	<div class="16_0"></div>
	
	<div class="15_30"></div>
	<div class="15_29"></div>
	<div class="15_28"></div>
	<div class="15_27"></div>
	<div class="15_26"></div>
	<div class="15_25"></div>
	<div class="15_24"></div>
	<div class="15_23"></div>
	<div class="15_22"></div>
	<div class="15_21"></div>
	<div class="15_20"></div>
	<div class="15_19"></div>
	<div class="15_18"></div>
	<div class="15_17"></div>
	<div class="15_16"></div>
	<div class="15_15"></div>
	<div class="15_14"></div>
	<div class="15_13"></div>
	<div class="15_12"></div>
	<div class="15_11"></div>
	<div class="15_10"></div>
	<div class="15_9"></div>
	<div class="15_8"></div>
	<div class="15_7"></div>
	<div class="15_6"></div>
	<div class="15_5"></div>
	<div class="15_4"></div>
	<div class="15_3"></div>
	<div class="15_2"></div>
	<div class="15_1"></div>
	<div class="15_0"></div>
	
	<div class="14_30"></div>
	<div class="14_29"></div>
	<div class="14_28"></div>
	<div class="14_27"></div>
	<div class="14_26"></div>
	<div class="14_25"></div>
	<div class="14_24"></div>
	<div class="14_23"></div>
	<div class="14_22"></div>
	<div class="14_21"></div>
	<div class="14_20"></div>
	<div class="14_19"></div>
	<div class="14_18"></div>
	<div class="14_17"></div>
	<div class="14_16"></div>
	<div class="14_15"></div>
	<div class="14_14"></div>
	<div class="14_13"></div>
	<div class="14_12"></div>
	<div class="14_11"></div>
	<div class="14_10"></div>
	<div class="14_9"></div>
	<div class="14_8"></div>
	<div class="14_7"></div>
	<div class="14_6"></div>
	<div class="14_5"></div>
	<div class="14_4"></div>
	<div class="14_3"></div>
	<div class="14_2"></div>
	<div class="14_1"></div>
	<div class="14_0"></div>
	
	<div class="13_30"></div>
	<div class="13_29"></div>
	<div class="13_28"></div>
	<div class="13_27"></div>
	<div class="13_26"></div>
	<div class="13_25"></div>
	<div class="13_24"></div>
	<div class="13_23"></div>
	<div class="13_22"></div>
	<div class="13_21"></div>
	<div class="13_20"></div>
	<div class="13_19"></div>
	<div class="13_18"></div>
	<div class="13_17"></div>
	<div class="13_16"></div>
	<div class="13_15"></div>
	<div class="13_14"></div>
	<div class="13_13"></div>
	<div class="13_12"></div>
	<div class="13_11"></div>
	<div class="13_10"></div>
	<div class="13_9"></div>
	<div class="13_8"></div>
	<div class="13_7"></div>
	<div class="13_6"></div>
	<div class="13_5"></div>
	<div class="13_4"></div>
	<div class="13_3"></div>
	<div class="13_2"></div>
	<div class="13_1"></div>
	<div class="13_0"></div>
	
	<div class="12_30"></div>
	<div class="12_29"></div>
	<div class="12_28"></div>
	<div class="12_27"></div>
	<div class="12_26"></div>
	<div class="12_25"></div>
	<div class="12_24"></div>
	<div class="12_23"></div>
	<div class="12_22"></div>
	<div class="12_21"></div>
	<div class="12_20"></div>
	<div class="12_19"></div>
	<div class="12_18"></div>
	<div class="12_17"></div>
	<div class="12_16"></div>
	<div class="12_15"></div>
	<div class="12_14"></div>
	<div class="12_13"></div>
	<div class="12_12"></div>
	<div class="12_11"></div>
	<div class="12_10"></div>
	<div class="12_9"></div>
	<div class="12_8"></div>
	<div class="12_7"></div>
	<div class="12_6"></div>
	<div class="12_5"></div>
	<div class="12_4"></div>
	<div class="12_3"></div>
	<div class="12_2"></div>
	<div class="12_1"></div>
	<div class="12_0"></div>
	
	<div class="11_30"></div>
	<div class="11_29"></div>
	<div class="11_28"></div>
	<div class="11_27"></div>
	<div class="11_26"></div>
	<div class="11_25"></div>
	<div class="11_24"></div>
	<div class="11_23"></div>
	<div class="11_22"></div>
	<div class="11_21"></div>
	<div class="11_20"></div>
	<div class="11_19"></div>
	<div class="11_18"></div>
	<div class="11_17"></div>
	<div class="11_16"></div>
	<div class="11_15"></div>
	<div class="11_14"></div>
	<div class="11_13"></div>
	<div class="11_12"></div>
	<div class="11_11"></div>
	<div class="11_10"></div>
	<div class="11_9"></div>
	<div class="11_8"></div>
	<div class="11_7"></div>
	<div class="11_6"></div>
	<div class="11_5"></div>
	<div class="11_4"></div>
	<div class="11_3"></div>
	<div class="11_2"></div>
	<div class="11_1"></div>
	<div class="11_0"></div>
	
	<div class="10_30"></div>
	<div class="10_29"></div>
	<div class="10_28"></div>
	<div class="10_27"></div>
	<div class="10_26"></div>
	<div class="10_25"></div>
	<div class="10_24"></div>
	<div class="10_23"></div>
	<div class="10_22"></div>
	<div class="10_21"></div>
	<div class="10_20"></div>
	<div class="10_19"></div>
	<div class="10_18"></div>
	<div class="10_17"></div>
	<div class="10_16"></div>
	<div class="10_15"></div>
	<div class="10_14"></div>
	<div class="10_13"></div>
	<div class="10_12"></div>
	<div class="10_11"></div>
	<div class="10_10"></div>
	<div class="10_9"></div>
	<div class="10_8"></div>
	<div class="10_7"></div>
	<div class="10_6"></div>
	<div class="10_5"></div>
	<div class="10_4"></div>
	<div class="10_3"></div>
	<div class="10_2"></div>
	<div class="10_1"></div>
	<div class="10_0"></div>
	
	<div class="9_30"></div>
	<div class="9_29"></div>
	<div class="9_28"></div>
	<div class="9_27"></div>
	<div class="9_26"></div>
	<div class="9_25"></div>
	<div class="9_24"></div>
	<div class="9_23"></div>
	<div class="9_22"></div>
	<div class="9_21"></div>
	<div class="9_20"></div>
	<div class="9_19"></div>
	<div class="9_18"></div>
	<div class="9_17"></div>
	<div class="9_16"></div>
	<div class="9_15"></div>
	<div class="9_14"></div>
	<div class="9_13"></div>
	<div class="9_12"></div>
	<div class="9_11"></div>
	<div class="9_10"></div>
	<div class="9_9"></div>
	<div class="9_8"></div>
	<div class="9_7"></div>
	<div class="9_6"></div>
	<div class="9_5"></div>
	<div class="9_4"></div>
	<div class="9_3"></div>
	<div class="9_2"></div>
	<div class="9_1"></div>
	<div class="9_0"></div>
	
	<div class="8_30"></div>
	<div class="8_29"></div>
	<div class="8_28"></div>
	<div class="8_27"></div>
	<div class="8_26"></div>
	<div class="8_25"></div>
	<div class="8_24"></div>
	<div class="8_23"></div>
	<div class="8_22"></div>
	<div class="8_21"></div>
	<div class="8_20"></div>
	<div class="8_19"></div>
	<div class="8_18"></div>
	<div class="8_17"></div>
	<div class="8_16"></div>
	<div class="8_15"></div>
	<div class="8_14"></div>
	<div class="8_13"></div>
	<div class="8_12"></div>
	<div class="8_11"></div>
	<div class="8_10"></div>
	<div class="8_9"></div>
	<div class="8_8"></div>
	<div class="8_7"></div>
	<div class="8_6"></div>
	<div class="8_5"></div>
	<div class="8_4"></div>
	<div class="8_3"></div>
	<div class="8_2"></div>
	<div class="8_1"></div>
	<div class="8_0"></div>
	
	<div class="7_30"></div>
	<div class="7_29"></div>
	<div class="7_28"></div>
	<div class="7_27"></div>
	<div class="7_26"></div>
	<div class="7_25"></div>
	<div class="7_24"></div>
	<div class="7_23"></div>
	<div class="7_22"></div>
	<div class="7_21"></div>
	<div class="7_20"></div>
	<div class="7_19"></div>
	<div class="7_18"></div>
	<div class="7_17"></div>
	<div class="7_16"></div>
	<div class="7_15"></div>
	<div class="7_14"></div>
	<div class="7_13"></div>
	<div class="7_12"></div>
	<div class="7_11"></div>
	<div class="7_10"></div>
	<div class="7_9"></div>
	<div class="7_8"></div>
	<div class="7_7"></div>
	<div class="7_6"></div>
	<div class="7_5"></div>
	<div class="7_4"></div>
	<div class="7_3"></div>
	<div class="7_2"></div>
	<div class="7_1"></div>
	<div class="7_0"></div>
	
	<div class="6_30"></div>
	<div class="6_29"></div>
	<div class="6_28"></div>
	<div class="6_27"></div>
	<div class="6_26"></div>
	<div class="6_25"></div>
	<div class="6_24"></div>
	<div class="6_23"></div>
	<div class="6_22"></div>
	<div class="6_21"></div>
	<div class="6_20"></div>
	<div class="6_19"></div>
	<div class="6_18"></div>
	<div class="6_17"></div>
	<div class="6_16"></div>
	<div class="6_15"></div>
	<div class="6_14"></div>
	<div class="6_13"></div>
	<div class="6_12"></div>
	<div class="6_11"></div>
	<div class="6_10"></div>
	<div class="6_9"></div>
	<div class="6_8"></div>
	<div class="6_7"></div>
	<div class="6_6"></div>
	<div class="6_5"></div>
	<div class="6_4"></div>
	<div class="6_3"></div>
	<div class="6_2"></div>
	<div class="6_1"></div>
	<div class="6_0"></div>
	
	<div class="5_30"></div>
	<div class="5_29"></div>
	<div class="5_28"></div>
	<div class="5_27"></div>
	<div class="5_26"></div>
	<div class="5_25"></div>
	<div class="5_24"></div>
	<div class="5_23"></div>
	<div class="5_22"></div>
	<div class="5_21"></div>
	<div class="5_20"></div>
	<div class="5_19"></div>
	<div class="5_18"></div>
	<div class="5_17"></div>
	<div class="5_16"></div>
	<div class="5_15"></div>
	<div class="5_14"></div>
	<div class="5_13"></div>
	<div class="5_12"></div>
	<div class="5_11"></div>
	<div class="5_10"></div>
	<div class="5_9"></div>
	<div class="5_8"></div>
	<div class="5_7"></div>
	<div class="5_6"></div>
	<div class="5_5"></div>
	<div class="5_4"></div>
	<div class="5_3"></div>
	<div class="5_2"></div>
	<div class="5_1"></div>
	<div class="5_0"></div>
	
	<div class="4_30"></div>
	<div class="4_29"></div>
	<div class="4_28"></div>
	<div class="4_27"></div>
	<div class="4_26"></div>
	<div class="4_25"></div>
	<div class="4_24"></div>
	<div class="4_23"></div>
	<div class="4_22"></div>
	<div class="4_21"></div>
	<div class="4_20"></div>
	<div class="4_19"></div>
	<div class="4_18"></div>
	<div class="4_17"></div>
	<div class="4_16"></div>
	<div class="4_15"></div>
	<div class="4_14"></div>
	<div class="4_13"></div>
	<div class="4_12"></div>
	<div class="4_11"></div>
	<div class="4_10"></div>
	<div class="4_9"></div>
	<div class="4_8"></div>
	<div class="4_7"></div>
	<div class="4_6"></div>
	<div class="4_5"></div>
	<div class="4_4"></div>
	<div class="4_3"></div>
	<div class="4_2"></div>
	<div class="4_1"></div>
	<div class="4_0"></div>
	
	<div class="3_30"></div>
	<div class="3_29"></div>
	<div class="3_28"></div>
	<div class="3_27"></div>
	<div class="3_26"></div>
	<div class="3_25"></div>
	<div class="3_24"></div>
	<div class="3_23"></div>
	<div class="3_22"></div>
	<div class="3_21"></div>
	<div class="3_20"></div>
	<div class="3_19"></div>
	<div class="3_18"></div>
	<div class="3_17"></div>
	<div class="3_16"></div>
	<div class="3_15"></div>
	<div class="3_14"></div>
	<div class="3_13"></div>
	<div class="3_12"></div>
	<div class="3_11"></div>
	<div class="3_10"></div>
	<div class="3_9"></div>
	<div class="3_8"></div>
	<div class="3_7"></div>
	<div class="3_6"></div>
	<div class="3_5"></div>
	<div class="3_4"></div>
	<div class="3_3"></div>
	<div class="3_2"></div>
	<div class="3_1"></div>
	<div class="3_0"></div>
	
	<div class="2_30"></div>
	<div class="2_29"></div>
	<div class="2_28"></div>
	<div class="2_27"></div>
	<div class="2_26"></div>
	<div class="2_25"></div>
	<div class="2_24"></div>
	<div class="2_23"></div>
	<div class="2_22"></div>
	<div class="2_21"></div>
	<div class="2_20"></div>
	<div class="2_19"></div>
	<div class="2_18"></div>
	<div class="2_17"></div>
	<div class="2_16"></div>
	<div class="2_15"></div>
	<div class="2_14"></div>
	<div class="2_13"></div>
	<div class="2_12"></div>
	<div class="2_11"></div>
	<div class="2_10"></div>
	<div class="2_9"></div>
	<div class="2_8"></div>
	<div class="2_7"></div>
	<div class="2_6"></div>
	<div class="2_5"></div>
	<div class="2_4"></div>
	<div class="2_3"></div>
	<div class="2_2"></div>
	<div class="2_1"></div>
	<div class="2_0"></div>
	
	<div class="1_30"></div>
	<div class="1_29"></div>
	<div class="1_28"></div>
	<div class="1_27"></div>
	<div class="1_26"></div>
	<div class="1_25"></div>
	<div class="1_24"></div>
	<div class="1_23"></div>
	<div class="1_22"></div>
	<div class="1_21"></div>
	<div class="1_20"></div>
	<div class="1_19"></div>
	<div class="1_18"></div>
	<div class="1_17"></div>
	<div class="1_16"></div>
	<div class="1_15"></div>
	<div class="1_14"></div>
	<div class="1_13"></div>
	<div class="1_12"></div>
	<div class="1_11"></div>
	<div class="1_10"></div>
	<div class="1_9"></div>
	<div class="1_8"></div>
	<div class="1_7"></div>
	<div class="1_6"></div>
	<div class="1_5"></div>
	<div class="1_4"></div>
	<div class="1_3"></div>
	<div class="1_2"></div>
	<div class="1_1"></div>
	<div class="1_0"></div>
	
	<div class="0_30"></div>
	<div class="0_29"></div>
	<div class="0_28"></div>
	<div class="0_27"></div>
	<div class="0_26"></div>
	<div class="0_25"></div>
	<div class="0_24"></div>
	<div class="0_23"></div>
	<div class="0_22"></div>
	<div class="0_21"></div>
	<div class="0_20"></div>
	<div class="0_19"></div>
	<div class="0_18"></div>
	<div class="0_17"></div>
	<div class="0_16"></div>
	<div class="0_15"></div>
	<div class="0_14"></div>
	<div class="0_13"></div>
	<div class="0_12"></div>
	<div class="0_11"></div>
	<div class="0_10"></div>
	<div class="0_9"></div>
	<div class="0_8"></div>
	<div class="0_7"></div>
	<div class="0_6"></div>
	<div class="0_5"></div>
	<div class="0_4"></div>
	<div class="0_3"></div>
	<div class="0_2"></div>
	<div class="0_1"></div>
	<div class="0_0"></div>
</div>

( <span style="color:blue;"><?php echo ""; ?></span>, <span style="color:red;"><?php echo ""; ?></span> )

<?php
	
	
	switch ($type) {
		case "5": {
			2.5 + 3.500 x 4 = 16.5
			2.5 + 3.625 x 4 = 17
			2.5 + 3.750 x 4 = 17.5
			2.5 + 3.875 x 4 = 18
			2.5 + 4.000 x 4 = 18.5
			2.5 + 4.125 x 4 = 19
			2.5 + 4.250 x 4 = 19.5
			2.5 + 4.375 x 4 = 20
			2.5 + 4.500 x 4 = 20.5
		}
		case "6": {
			2.5 + 3.500 x 5 = 20.000
			2.5 + 3.625 x 5 = 20.625
			2.5 + 3.750 x 5 = 21.250
			2.5 + 3.875 x 5 = 21.875
			2.5 + 4.000 x 5 = 22.500
			2.5 + 4.125 x 5 = 23.125
			2.5 + 4.250 x 5 = 23.750
			2.5 + 4.375 x 5 = 24.375
			2.5 + 4.500 x 5 = 25.000
		}
	}
	
	switch ($type) {
		case "5": {
			2.5 + 3.500 x 4 + 5.25 = 21.750
			2.5 + 3.625 x 4 + 5.25 = 22.250
			2.5 + 3.750 x 4 + 5.25 = 22.750
			2.5 + 3.875 x 4 + 5.25 = 23.250
			2.5 + 4.000 x 4 + 5.25 = 23.750
			2.5 + 4.125 x 4 + 5.25 = 24.250
			2.5 + 4.250 x 4 + 5.25 = 24.750
			2.5 + 4.375 x 4 + 5.25 = 25.250
			2.5 + 4.500 x 4 + 5.25 = 25.750
		}
		case "6": {
			2.5 + 3.500 x 5 + 5.25 = 25.250
			2.5 + 3.625 x 5 + 5.25 = 25.875
			2.5 + 3.750 x 5 + 5.25 = 26.500
			2.5 + 3.875 x 5 + 5.25 = 27.125
			2.5 + 4.000 x 5 + 5.25 = 27.750
			2.5 + 4.125 x 5 + 5.25 = 28.375
			2.5 + 4.250 x 5 + 5.25 = 29.000
			2.5 + 4.375 x 5 + 5.25 = 29.625
			2.5 + 4.500 x 5 + 5.25 = 30.250
		}
	}
	
	switch ($type) {
		case "21.5 - ": {
			2.5 + 3.500 x 4 + 5 = 21.500
			2.5 + 3.500 x 4 + 5.5 = 22
		}
		case "6": {
			
		}
	}
	
	switch ($type) {
		// 3½ x 4
		case "21.50": {
			2.5 + 3.500 x 4 + 5.00 = 21.50
		}
		case "21.75": {
			2.5 + 3.500 x 4 + 5.25 = 21.75
		}
		// 3½+ x 4
		case "22.00": {
			2.5 + 3.500 x 4 + 5.50 = 22.00
			2.5 + 3.625 x 4 + 5.00 = 22.00
		}
		case "22.25": {
			2.5 + 3.625 x 4 + 5.25 = 22.25
		}
		// 3¾ x 4
		case "22.50": {
			2.5 + 3.625 x 4 + 5.50 = 22.50
			2.5 + 3.750 x 4 + 5.00 = 22.50
		}
		case "22.75": {
			2.5 + 3.750 x 4 + 5.25 = 22.75
		}
		// 4- x 4
		case "23.00": {
			2.5 + 3.750 x 4 + 5.50 = 23.00
			2.5 + 3.875 x 4 + 5.00 = 23.00
		}
		case "23.25": {
			2.5 + 3.875 x 4 + 5.25 = 23.25
		}
		// 4 x 4
		case "23.50": {
			2.5 + 3.875 x 4 + 5.50 = 23.50
			2.5 + 4.000 x 4 + 5.00 = 23.50
		}
		case "23.75": {
			2.5 + 4.000 x 4 + 5.25 = 23.75
		}
		case "24.00": {
			2.5 + 4.000 x 4 + 5.50 = 24.00
			2.5 + 4.125 x 4 + 5.00 = 24.00
		}
		// 4+ x 4
		case "24.25": {
			2.5 + 4.125 x 4 + 5.25 = 24.25
		}
		case "24.50": {
			2.5 + 4.125 x 4 + 5.50 = 24.50
			2.5 + 4.250 x 4 + 5.00 = 24.50
		}
		// 4¼ x 4
		case "24.75": {
			2.5 + 4.250 x 4 + 5.25 = 24.75
		}
		case "25.00": {
			2.5 + 4.250 x 4 + 5.50 = 25.00
			2.5 + 4.375 x 4 + 5.00 = 25.00
			2.5 + 3.500 x 5 + 5.00 = 25.00
		}
		// 4¼+ x 4
		case "25.25": {
			2.5 + 4.375 x 4 + 5.25 = 25.25
			2.5 + 3.500 x 5 + 5.25 = 25.25
		}
		case "25.50": {
			2.5 + 4.375 x 4 + 5.50 = 25.50
			2.5 + 4.500 x 4 + 5.00 = 25.50
			2.5 + 3.500 x 5 + 5.50 = 25.50
		}
		// 3½+ x 5
		case "25.75": {
			2.5 + 4.500 x 4 + 5.250 = 25.75
			2.5 + 3.625 x 5 + 5.125 = 25.75
		}
		case "26.00": {
			2.5 + 4.500 x 4 + 5.500 = 26.00
			2.5 + 3.625 x 5 + 5.375 = 26.00
		}
		// 3¾ x 5
		case "26.25": {
			2.5 + 3.750 x 5 + 5.00 = 26.25
		}
		case "26.50": {
			2.5 + 3.750 x 5 + 5.25 = 26.50
		}
		case "26.75": {
			2.5 + 3.750 x 5 + 5.50 = 26.75
		}
		// 3¾+ x 5
		case "27.00": {
			2.5 + 3.875 x 5 + 5.125 = 27.00
		}
		case "27.25": {
			2.5 + 3.875 x 5 + 5.375 = 27.25
		}
		// 4 x 5
		case "27.50": {
			2.5 + 4.000 x 5 + 5.00 = 27.50
		}
		case "27.75": {
			2.5 + 4.000 x 5 + 5.25 = 27.75
		}
		case "28.00": {
			2.5 + 4.000 x 5 + 5.50 = 28.00
		}
		// 4+ x 5
		case "28.25": {
			2.5 + 4.125 x 5 + 5.125 = 28.25
		}
		case "28.50": {
			2.5 + 4.125 x 5 + 5.375 = 28.50
		}
		// 4¼ x 5
		case "28.75": {
			2.5 + 4.250 x 5 + 5.00 = 28.75
		}
		case "29.00": {
			2.5 + 4.250 x 5 + 5.25 = 29.00
		}
		case "29.25": {
			2.5 + 4.250 x 5 + 5.50 = 29.25
		}
		// 4¼+ x 5
		case "29.50": {
			2.5 + 4.375 x 5 + 5.125 = 29.50
		}
		case "29.75": {
			2.5 + 4.375 x 5 + 5.375 = 29.75
		}
		// 4½
		case "30.00": {
			2.5 + 4.500 x 5 + 5.00 = 30.00
		}
		case "30.25": {
			2.5 + 4.500 x 5 + 5.25 = 30.25
		}
		case "30.50": {
			2.5 + 4.500 x 5 + 5.50 = 30.50
		}
		
	}
	
?>

<?php
	
	
	
?>

</html>