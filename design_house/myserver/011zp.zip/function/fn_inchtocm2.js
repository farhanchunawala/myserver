
function inchtocm(x) {
	x = x * 2.54;
	return x;
}
