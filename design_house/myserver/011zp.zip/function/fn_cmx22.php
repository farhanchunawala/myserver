<?php
	
	function scale($x) {
		$x = $x * 2.54 * 10;
		return $x;
	}
	
?>