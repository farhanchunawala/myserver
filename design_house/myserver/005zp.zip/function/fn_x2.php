<?php
	function scale($x) {
		$x = $x * 2;
		return $x;
	}
?>