
notepad++ C:/xampp/htdocs/myserver/appwall.php
notepad++ C:/xampp/htdocs/myserver/appwall2.php
	notepad++ C:/xampp/htdocs/myserver/appwall/cust/customerlist.php
		notepad++ C:/xampp/htdocs/myserver/appwall/cust/newcustomer.php
		notepad++ C:/xampp/htdocs/myserver/appwall/cust/customer_info.php
			notepad++ C:/xampp/htdocs/myserver/appwall/cust/sub_cust_save.php
			notepad++ C:/xampp/htdocs/myserver/appwall/pattern/pattern.php
				notepad++ C:/xampp/htdocs/myserver/appwall/cust/sub_cust_save.php
				notepad++ C:/xampp/htdocs/myserver/appwall/meas/sub_meas_save.php
				notepad++ C:/xampp/htdocs/myserver/appwall/pattern/sub_pattern_table.php
					notepad++ C:/xampp/htdocs/myserver/appwall/pattern/tb_garb_info.php
					notepad++ C:/xampp/htdocs/myserver/appwall/pattern/tb_garb_fit.php
					notepad++ C:/xampp/htdocs/myserver/appwall/pattern/tb_garb_style.php
					notepad++ C:/xampp/htdocs/myserver/appwall/pattern/tb_garb_sp.php
				notepad++ C:/xampp/htdocs/myserver/appwall/arr/atb_cust.php
				notepad++ C:/xampp/htdocs/myserver/appwall/arr/atb_meas.php
				notepad++ C:/xampp/htdocs/myserver/appwall/pattern/pattern_save.php
				