<!DOCTYPE html>
<html lang="en">
<head>
	<?php $sr=$_GET['sr'];  echo "<title>$sr Entry</title>";
	$fdir='../../';  include $fdir.'svr/filepath.php';  include $bootstrapcdn_php;
	$svr_mode=$_GET['svr_mode'];  include $svr_mode_php; ?>
	<script src="https://unpkg.com/vue"></script>
	<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
	<link rel="stylesheet" href="<?php echo $searchfilter_css ?>">
	<style>
		th {padding: 5px;
			background-color: white;
			position: -webkit-sticky;
			position: sticky;
			top: 0;
			white-space: nowrap;
		}
		td {white-space: nowrap;
		}
	</style>
</head>
<body>
<?php
	include $fn_inchtotextround2_php;
	include $fn_cmtoinchtext_php;
	
	if ($_GET['cs']==1) include $create_style_php;
?>

<div id="app" class="container-fluid mx-n2">
<form method="post" action="<?php echo "$pattern_save2_php?svr_mode=$svr_mode&sr=$sr"; ?>" >
	<div id="accordion">
		
		<div class="card" style="width:570px"><div class="card-header"><a class="btn" data-bs-toggle="collapse" href="#collapse1" style="color:black"><b>{{cust.sr+' '+cust.name+' '+cust.surname}}</b></a></div>
		<div id="collapse1" class="collapse" data-bs-parent="#accordion"><div class="card-body px-2 py-0">
			<span v-for="(x,kx) in cust" :key="kx" > <label :for="kx" class="p-4">{{kx}}
				<input tabindex="1" type="text" class="form-control p-2" :name="kx" :value="x" style="width:135px" />
			</label></span>
		</div></div></div>
		
		<div class="card" style="width:570px"><div class="card-header"><a class="btn" data-bs-toggle="collapse" href="#collapse2" style="color:black"><b>Body Measure</b></a></div>
		<div id="collapse2" class="collapse" data-bs-parent="#accordion"><div class="card-body p-0">
			<div class="form-group form-inline d-flex flex-wrap align-content-around">
			<div v-for="(x,kx) in meas" :key="kx" class="p-3">
				<label class="form-inline" :for="kx">{{kx}}</label>
				<div><div class="btn-group">
				<input  tabindex="110" type="text"  class="form-control p-1"  id=""  value=""					style="height:36px; width:60px; font-size: 16px"  oninput=inchtocm(this.value,"")  onchange=inchtocm(this.value,"") />
				<input  tabindex="130" type="text"  class="form-control p-1"  id=""  value=""  :name="kx"	style="height:36px; width:50px; font-size: 16px"  oninput=cmtoinch(this.value,"")  onchange=cmtoinch(this.value,"") />
			</div></div></div></div>
		</div></div></div>
		
		<div class="form-group form-inline"><div class="d-flex flex-nowrap bg-light">
			<styletable v-if="styles[0]" :style="styles[0]" :fit="fits[0]"></styletable>
		</div></div>
	</div>
</form>
</div>

<script> "use strict";
	var fdir = '../../';
	let url		= new URL(window.location.href);
	let svr_mode= url.searchParams.get("svr_mode");
	let sr		= url.searchParams.get("sr");
</script>
<script>
const app = Vue.createApp({
	data() {
		return {
			cust:		{},
			meas:		{},
			styles:	[],
			fits:		[]
		}
	},
	created() {
		axios.post(fdir+'qry/pdo_select.php?svr_mode='+svr_mode, {
		sql: 'SELECT * FROM style WHERE sr='+sr
		}).then(response => { this.styles = response.data
		}).catch(error => { console.log(error); this.errored1 = true
		}).finally(() => this.loading1 = false)
		
		axios.post(fdir+'qry/pdo_select.php?svr_mode='+svr_mode, {
		sql: 'SELECT * FROM fit WHERE sr='+sr
		}).then(response => { this.fits = response.data
		}).catch(error => { console.log(error); this.errored1 = true
		}).finally(() => this.loading1 = false)
		
		axios.post(fdir+'qry/pdo_select.php?svr_mode='+svr_mode, {
		sql: 'SELECT * FROM meas WHERE sr='+sr
		}).then(response => { this.meas = response.data[0]
		}).catch(error => { console.log(error); this.errored1 = true
		}).finally(() => this.loading1 = false)
		
		axios.post(fdir+'qry/pdo_select.php?svr_mode='+svr_mode, {
		sql: 'SELECT * FROM cust WHERE sr='+sr
		}).then(response => { this.cust = response.data[0]
		}).catch(error => { console.log(error); this.errored1 = true
		}).finally(() => this.loading1 = false)
	}
})
</script>
<script src="<?php echo $styletable_js; ?>"></script>
<script> const mountedApp = app.mount('#app') </script>
<?php mysqli_close($dbc); ?>
</body>
</html>