<?php
	$atb_fabric = array('fabric_id', 'id_code', 'brand', 'name', 'fabric_type', 'color', 'texture', 'composition', 'supplier', 'cp', 'fp');
	$atb_fabric2 = array('id_code', 'brand', 'name', 'fabric_type', 'color', 'texture', 'composition', 'supplier', 'cp', 'fp');
	
	$atb_fabricpiece = array('piece_id', 'fabric_id', 'pana', 'clothln', 'location');
	$atb_fabricpiece2 = array('fabric_id', 'pana', 'clothln', 'location');
	$atb_fabricpiece3 = array('pana', 'clothln', 'location');
	$atb_fabricpiece4 = array('piece_id', 'pana', 'clothln', 'location');
	
?>