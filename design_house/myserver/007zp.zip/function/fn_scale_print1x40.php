<?php
	
	function scale($x) {
		$a = $x * 1500 / inchtocm(41.5) ;
		return $a;
	}
	
?>