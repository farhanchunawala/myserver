<?php

$localhost
MyServer  : http://localhost/MyServer/
phpmyadmin: http://localhost/phpmyadmin/
Codefinder: http://localhost/MyServer/apps_tools/codefinder.php?cf=0

$Cpanel
Cpanel: https://sg2plzcpnl486124.prod.sin2.secureserver.net:2083/cpsess0067662981/frontend/paper_lantern/index.html?login=1&post_login=46862016919125

$ZnM
Appwall: https://www.zollandmeter.com/appwall.php

?>


<!--	children
notepad++ C:/xampp/htdocs/myserver/svr_mode.php
notepad++ C:/xampp/htdocs/myserver/appwall/navbar.php

notepad++ C:/xampp/htdocs/myserver/appwall/cust/customerlist.php
notepad++ C:/xampp/htdocs/myserver/appwall/entry/tasktracker.php
notepad++ C:/xampp/htdocs/myserver/appwall/fabric/fabric_inventory.php
-->
