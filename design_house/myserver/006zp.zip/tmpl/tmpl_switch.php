<?php

	switch ($type) {
		
		case "shirt": {
			
		} break;
		
		case "kurta": {
			
		} break;
		
		case "pathani": {
			
		} break;
		
		case "kandura": {
			
		} break;
		
		case "pant": {
			
		} break;
		
		case "bpyjama": {
			
		} break;
		
		case "pyjama": {
			
		} break;
		
		case "salwar": {
			
		} break;
		
		case "aligard": {
			
		} break;
		
		case "churidar": {
			
		} break;
		
		default: {
			
		}
	}
	
?>