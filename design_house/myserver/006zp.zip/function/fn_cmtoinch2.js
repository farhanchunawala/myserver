
function cmtoinch(x) {
	x = x / 2.54;
	return x;
}
