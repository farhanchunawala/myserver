<?php
	$garb_book_date												= date("y-m-d");
?>