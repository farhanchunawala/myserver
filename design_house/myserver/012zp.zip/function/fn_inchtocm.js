
function inchtocm(valNum, val_id) {
	
	document.getElementById(val_id+"cm").value = texttocmround(valNum).toFixed(1);
	
}
