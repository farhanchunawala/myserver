
function cmtoinch(valNum, val_id) {
	
	document.getElementById(val_id+"in").value = inchtotextround(valNum*0.3937008);
	
}