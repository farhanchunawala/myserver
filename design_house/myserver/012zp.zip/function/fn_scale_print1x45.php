<?php
	
	function scale($x) {
		$a = $x * 1500 / inchtocm(46.5) ;
		return $a;
	}
	
?>