app.component('styletable', {
	props: {
		// style:	{ type: Object },
		// fit:		{ type: Object },
		garb:	{ type: Object },
		garbtype:	{ type: String },
		garbstyles:	{ type: Object }
	},
	template: /*html*/ `
	<!--<div v-for="(mystyle,style_key) in garbstyles" :key="style_key">{{mystyle}}</div>-->
	<!--<div :id="accRef('accordion'+garbtype,style_key)" v-if="garbtype[style_key+'count'] || style_key=='0'">
	<div class="card"><div class="card-header" style="background-color:lightgrey">
		<a class="btn" data-bs-toggle="collapse" :href="'#'+accRef('collapse'+garbtype,style_key)" style="color:black; white-space:nowrap"><b>{{garbtype+'.'+style_key+' x '+garb.count}}</b></a>
	</div>
	<div :id="accRef('collapse'+garbtype,style_key)" class="collapse show" :data-bs-parent="'#'+accRef('accordion'+garbtype,style_key)"><div class="card-body px-2 py-0">-->
		
		<table class="table table-borderless table-sm">
		<thead><tr><th></th></tr></thead>
		<tbody>
			<tr><td>description	</td><td v-for="ct in garbstyles" style="padding:2px"><input type="text" class="myInput" name="'+myStyle.stylename+x+c+'" value=""/></td></tr>
			<tr><td>pairing		</td><td v-for="ct in garbstyles" style="padding:2px"><input type="text" class="myInput" name="'+myStyle.stylename+x+c+'" value="'+String.fromCharCode(pairing)+'"/></td></tr>
			<tr><td>submit_date	</td><td v-for="ct in garbstyles" style="padding:2px"><input type="text" class="myInput" name="'+myStyle.stylename+x+c+'" value="" placeholder="yyyy-mm-dd"/></td></tr>
		</tbody>
		</table>
		
		<div :id="accRef('accordionstyle'+garbtype,'')">
			
			<div class="card"><div class="card-header"><a class="btn" data-bs-toggle="collapse" :href="'#'+accRef('collapsefit'+garbtype,'')" style="color:black"><b>Fit</b></a></div>
			<div :id="accRef('collapsefit'+garbtype,'')" class="collapse" :data-bs-parent="'#'+accRef('accordionstyle','')">
			<div class="card-body px-2 py-0">
			<table class="table table-borderless table-sm">
			<thead><tr><th></th></tr></thead>
			<tbody>
				<span v-for="(fit,fit_key) in fits">
				<tr v-for="(x,kx) in fit">
					<td>{{kx}}</td>
					<td style="padding:1px 8px"><div class="btn-group">
						<input  tabindex="120" type="text"  class="myInput"  :id="kx+'x'+'in'"  :value="inchtotextround(x)"		style="width:60px; background-color:hsl(230, 0%, 98%)" />
						<input  tabindex="141" type="text"  class="myInput"  :id="kx+'x'+'cm'"  :value="pfx(x)"  :name="kx+'x'"	style="width:50px" />
					</div></td>
				</tr></span>
			</tbody>
			</table>
			</div></div></div>
			
			<div class="card"><div class="card-header" style="white-space: nowrap">
				<a class="btn" data-bs-toggle="collapse" :href="'#'+accRef('collapsestyle'+garbtype,'')" style="color:black"><b>Style</b></a>
			</div>
			<div :id="accRef('collapsestyle'+garbtype,'')" class="collapse" :data-bs-parent="'#'+accRef('accordionstyle'+garbtype,'')">
			<div class="card-body px-2 py-0">
				<table class="table table-borderless table-sm">
				<thead><tr><th></th></tr></thead>
				<tbody>
					<span v-for="(style_key,ix) in garbstyles">
					<tr v-for="(x,kx) in styles[style_key.style]" ><template v-if="kx!='sr' && kx!='garbtype'">
						<td v-if="ix==0">{{kx}}</td>
						<td style="padding:2px">
							<p v-if="kx=='save_date'" style="margin:0px">{{myDate(styles[style_key.style][kx])}}<br/>
							<a class="btn" @click="saveStyle(style_key, ix)" style="border: 1px solid lightgrey"><b>save</b></a></p>
							<input v-else class="myInput" type="text" @click="lmkChange(kx,ix)" v-model="garbstyles[ix][kx]" :placeholder="styles[style_key.style][kx]">
							<ul id="myUL" v-if="kx!='save_date'" v-show="lmk[kx][ix]"><li>
								<a v-for="x in sel_styles[kx]" @click="selectType(x, style_key.style, kx, ix)">{{x}}</a>
							</li></ul>
						</td>
					</template></tr></span>
				</tbody>
				</table>
			</div></div></div>
			
			<!--<div :id="'tb_garbsp'+style_key"></div>-->
		</div>
		
	<!--</div></div></div></div>-->
	`,
	data() {
		return {
			styles:	{},
			fits:		{},
			lmk:		{
				style: [],		collar_type: [],	cuff_ln: [],	cuff_type: [],		pocket_type: [],	shoulder_type: [],	taweez_type: [],
				belt_type: [],	chainfly: [],		pocket: [],		backpocket: [],	watchpocket: [],	bottom_type: [],		crease: [],	
				note1: [],		note2: [],			note3: []
			},
			sel_styles: {
				style:			[],
				collar_type:	['', 'rmpc', 'lspc', 'bc', 'no collar'],
				cuff_type:		['', 'cut', 'round', 'no cuff'],
				pocket_type:	['', 'v', 'square', 'round'],
				shoulder_type:	['', 'regular', 'v', 'double v'],
				taweez_type:	['', 'v', 'square'],
			}
		}
	},
	methods: {
		myDate (date) {
			return new Date(date).toDateString();
		},
		lmkChange(kx,ix) { this.lmk[kx][ix]=1 },
		selectType(x, style_key, kx, ix) {
			if (kx=='style') this.garbstyles[ix]['style']=x;
			else {
				this.garbstyles[ix][kx] = x;
				// this.styles[style_key][kx] = x;
			}
			// this.styles[style_key][kx] = x
			this.lmk[kx][ix]=0;
		},
		saveStyle(style_key, ix) {
			// if (this.dish.dish_id!=1) {
				
				// if (this.dishname_change) this.dish.dish_name = this.dishname_change;
				
				for(x in this.styles[style_key.style]) {
					if (style_key[x]) {
						this.styles[style_key.style][x] = style_key[x];
						for (iy in this.garbstyles) {
							if (x!='style' && this.garbstyles[iy][x]==this.styles[style_key.style][x]) delete this.garbstyles[iy][x]
						}
					}
				}
				
				axios.post(fdir+'qry/pdo_update.php?svr_mode='+svr_mode, {
				myArr:this.styles[style_key.style],  tbl:'style',  whr:'WHERE sr="'+this.styles[style_key.style]['sr']+'" AND garbtype="'+this.styles[style_key.style]['garbtype']+'"  AND style="'+style_key.style+'"'
				}).then(response => {
					if(response.data) alert(response.data);
					else alert ('saved');
				}).catch(error => { console.log(error.response.data); this.errored1 = true
				}).finally(() => this.loading1 = false)
				
			// } else {
				
			// 	this.dish.dish_id = null;
			// 	this.dish.dish_name = this.dishname_change;
				
			// 	axios.post(fdir+'qry/pdo_insert.php?svr_mode='+svr_mode, {
			// 	myArr:this.dish,  tbl:'dish'
			// 	}).then(response => {
			// 		if(response.data) alert(response.data);
			// 		else alert ('saved');
			// 	}).catch(error => { console.log(error.response.data); this.errored1 = true
			// 	}).finally(() => this.loading1 = false)
				
			// }
		}
	},
	computed: {
		pfx() { return (x) => parseFloat(x).toFixed(1) },
		accRef() { return (type,style_key) => type+style_key//.replace(".", "_") 
		},
		inchtotextround() { return (x) => {
			x *= 0.39370;
			let y = Math.floor(x);
			if (y==0) var a = 0;
			else      var a = x - y;
			
			if	  	  (a < 0.0625)					   z = y;
			else if (a >= 0.0625 && a < 0.1875) z = y+'+';
			else if (a >= 0.1875 && a < 0.3125) z = y+'¼';
			else if (a >= 0.3125 && a < 0.4375) z = y+'¼+';
			else if (a >= 0.4375 && a < 0.5625) z = y+'½';
			else if (a >= 0.5625 && a < 0.6875) z = y+'½+';
			else if (a >= 0.6875 && a < 0.8125) z = y+'¾';
			else if (a >= 0.8125 && a < 0.9375) z = (y+1)+'=';
			else if (a >= 0.9375)				   z = y+1;
			
			return z
		}}
	},
	created() {
		axios.post(fdir+'qry/pdo_select.php?svr_mode='+svr_mode, {
		sql: 'SELECT * FROM style WHERE sr='+sr+' AND garbtype="'+this.garbtype+'"'
		}).then(response => { //this.styles = response.data
			for (let style of response.data) {
				this.styles[style['style']] = {};
				for (let x in style) this.styles[style['style']][x] = style[x];
				this.sel_styles.style.push(style['style']);
				if (!this.styles['default']) {
					this.styles['default'] = {};
					for (let x in style) this.styles['default'][x] = null;
				}
			}
		}).catch(error => { console.log(error); this.errored1 = true
		}).finally(() => this.loading1 = false)
		
		axios.post(fdir+'qry/pdo_select.php?svr_mode='+svr_mode, {
		sql: 'SELECT * FROM fit WHERE sr='+sr+' AND garbtype="'+this.garbtype+'"'
		}).then(response => { //this.fits = response.data
			for (let fit of response.data) {
				this.fits[fit['style']] = {};
				for (let x in fit) this.fits[fit['style']][x] = fit[x];
				if (!this.fits['default']) {
					this.fits['default'] = {};
					for (let x in fit) this.fits['default'][x] = null;
				}
			}
		}).catch(error => { console.log(error); this.errored1 = true
		}).finally(() => this.loading1 = false)
	}
})