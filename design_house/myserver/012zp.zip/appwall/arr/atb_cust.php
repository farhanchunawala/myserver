<?php
	$atb_cust = array('sr', 'name', 'surname', 'mobile_no1', 'mobile_no2', 'mobile_no3');
	
	$atb_cust2 = array('name', 'surname', 'mobile_no1', 'mobile_no2', 'mobile_no3');
?>