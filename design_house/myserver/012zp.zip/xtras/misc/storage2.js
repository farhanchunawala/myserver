
const items = {
	scales : ['l_scale', 'shape_scale', 'straight_scale', 'sleeve_scale', ],
};
