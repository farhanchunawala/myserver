<!DOCTYPE html>
<html lang="en">
<head>
	<title></title>
	<?php include 'plugins_n_libraries/bootstrapcdn.php'; ?>
</head>
<body>
	<div class="container-fluid p-5">
		
		
		
	</div>
</body>
</html>