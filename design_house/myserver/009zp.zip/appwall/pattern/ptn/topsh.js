function TopSh() {
	this.x_Markshoulder	= inchtocm(2.5);
	
	this.x_Rounding		= inchtocm(2.5);
	this.x_Length			= parseFloat(myMeas.shoulder_ln)/2 + inchtocm(0.5);
	
	this.y_Rounding		= inchtocm(1.75);
	this.y_Collarln		= inchtocm(2);
	this.y_Height			= inchtocm(6);
}
