app.component('styletable', {
	props: {
		style:{ type: Object },
		fit:	{ type: Object }
	},
	template: /*html*/ `
	<div :id="'accordion'+style.stylename" >
	<div class="card"><div class="card-header" style="background-color:lightgrey">
		<a class="btn" data-bs-toggle="collapse" :href="'#collapse'+style.stylename" style="color:black"><b>{{style.stylename+' '+style.garbcount}}</b></a>
	</div>
	<div :id="'collapse'+style.stylename" class="collapse show" :data-bs-parent="'#accordion'+style.stylename"><div class="card-body px-2 py-0">
		
		<div :id="'tb_garb_info'+style.stylename"></div>
		<div :id="'accordionstyle'+style.stylename">
			
			<!--<div :id="'tb_stylefit'+style.stylename"></div>-->
			<div class="card"><div class="card-header"><a class="btn" data-bs-toggle="collapse" :href="'#collapsefit'+style.stylename" style="color:black"><b>Fit</b></a></div>
			<div :id="'collapsefit'+style.stylename" class="collapse" :data-bs-parent="'#accordionstyle'+style.stylename">
			<div class="card-body px-2 py-0">
			<table class="table table-borderless table-sm">
			<thead><tr><th></th></tr></thead>
			<tbody>
				<tr v-for="(x,kx) in fit">
					<td>{{kx}}</td>
					<td><div class="btn-group">
						<input  tabindex="120" type="text"  class="form-control p-1"  :id="style.stylename+'x'+'in'"  :value="inchtotextround(x)"										style="width:60px" />
						<input  tabindex="141" type="text"  class="form-control p-1"  :id="style.stylename+'x'+'cm'"  :value="pfx(x)"  :name="style.stylename+'x'"	style="width:50px" />
					</div></td>
				</tr>
			</tbody>
			</table>
			</div></div></div>
			
			<!--<div :id="'tb_garbstyle'+style.stylename"></div>-->
			<div class="card"><div class="card-header"><a class="btn" data-bs-toggle="collapse" :href="'#collapsestyle'+style.stylename" style="color:black"><b>Style</b></a></div>
				<div :id="'collapsestyle'+style.stylename" class="collapse" :data-bs-parent="'#accordionstyle'+style.stylename">
				<div class="card-body px-2 py-0">
				<table class="table table-borderless table-sm">
				<thead><tr><th></th></tr></thead>
				<tbody>
					<tr v-for="(x,kx) in style" >
					<td>{{kx}}</td>
					<td><select class="form-select p-0" tabindex="" name="'style.stylename+x+c+'" style="width:120px">
					<option value="default">Default</option>
					<option value="'+y+'" >'+dp+'</option>
					</select></td>
					</tr>
				</tbody>
				</table>
			</div></div></div>
			
			<!--<div :id="'tb_garbsp'+style.stylename"></div>-->
		</div>
		
	</div></div></div>
	</div>
	`,
	data() {
		return {}
	},
	computed: {
		pfx() { return (x) => parseFloat(x).toFixed(1) },
		inchtotextround() { return (x) => {
			x *= 0.39370;
			let y = Math.floor(x);
			if (y==0) var a = 0;
			else      var a = x - y;
			
			if	  	  (a < 0.0625)					   z = y;
			else if (a >= 0.0625 && a < 0.1875) z = y+'+';
			else if (a >= 0.1875 && a < 0.3125) z = y+'¼';
			else if (a >= 0.3125 && a < 0.4375) z = y+'¼+';
			else if (a >= 0.4375 && a < 0.5625) z = y+'½';
			else if (a >= 0.5625 && a < 0.6875) z = y+'½+';
			else if (a >= 0.6875 && a < 0.8125) z = y+'¾';
			else if (a >= 0.8125 && a < 0.9375) z = (y+1)+'=';
			else if (a >= 0.9375)				   z = y+1;
			
			return z
		}}
	},
	methods: {
		
	}
})