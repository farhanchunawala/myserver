<?php
	
	function scale($x) {
		$a = $x * 1500 / inchtocm(36.5) ;
		return $a;
	}
	
?>