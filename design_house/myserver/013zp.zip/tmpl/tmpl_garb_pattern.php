<?php
	$x_s_m = 1;
	$y_s_m = 1;
	$vertex = 'A';
	$s_rotate = 0;
	$fill = 'lightblue';
	$opacity = 1;
	include 'pattern/shirt_front.php';
?>
