<?php
	$y_pana = $pana[$i];
	$x_clothln = ($clothln[$i]!=0) ? $clothln[$i] / 2.54 : "" ;
?>