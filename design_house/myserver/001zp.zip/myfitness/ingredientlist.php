<!DOCTYPE html>
<html lang="en">
<head><title>Ingredient List</title>
	<?php $fdir='../';  include $fdir.'svr/filepath.php';  include $bootstrapcdn_php; 
	$svr_mode=$_GET['svr_mode'];  $srh=$_GET['srh']; ?>
</head>
<body>

<?php $srh=$_GET['srh'];
	$navtitle='New';  $navlink=$foodinfo_php."?svr_mode=$svr_mode&food_id=0&sv=0";  include $navbar_php;
?>
<div class="container">
	<h1 class="mt-4 mb-5"> &nbsp </h1>
	<div id='listtable'></div>
</div>

<script>
	let fdir='../';
	let url_string = window.location.href;
	let url = new URL(url_string);
	let svr_mode = url.searchParams.get("svr_mode");
	//document.getElementById("svr_mode_script").src=fdir+"svr_mode.js";
</script>
<script src="<?php echo $loaddoc_js; ?>"></script>
<script src="<?php echo $listtable_js; ?>"></script>
<script>
	//if (document.getElementById("srh").addEventListener("input", function(){ return true; })) srh=1; else srh=0;
	//if (document.getElementById("srh").value=="") srh=0; else srh=1;
	function foodList(xhttp) {
		const foods = JSON.parse(xhttp.responseText);
		const myObjs = [];
		
		let i=0;
		for (let food of foods) {
			myObjs[i]={};
			for (let x in food) {
				myObjs[i][x] = food[x];
			} i++;
		}
		listTable(myObjs, 'food', 0);
	}
	loadDoc(fdir+'qry/pdo_select.php?svr_mode='+svr_mode, foodList, 'sql='+encodeURIComponent('SELECT * FROM food ORDER BY food_id'));
</script>
</body>
</html>